"""Read a Vectorworks file out to a small JSON file beside it, so the drawing can be worked on with
Vectorworks closed (Rig Studio and Claude read it through Dropbox).

`<name>.rigread.json` holds the document's layers and classes, every plug-in object with all its
fields (lighting devices, truss, hoists, decks...), every symbol, and the shapes, in inches. It is
kept under Dropbox's 5 MB text limit by leaving out the plainest shapes first (it says how many).
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

SUFFIX = ".rigread.json"
LIMIT = 4_800_000  # bytes; Dropbox reads text files up to 5 MiB


def target_for(vwx: Path) -> Path:
    return vwx.with_name(vwx.stem + SUFFIX)


def fit(readout: dict, limit: int = LIMIT) -> tuple[bytes, int]:
    """The read-out as compact JSON under `limit` bytes. Plug-in objects and symbols always stay;
    plain shapes go first, the ones with the most points first, then the rest. Returns the bytes
    and how many shapes were left out."""
    def dump(r):
        return json.dumps(r, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    data = dump(readout)
    if len(data) <= limit:
        return data, 0
    objs = readout["objects"]
    keep = [o for o in objs if "plugin" in o or "symbol" in o]
    shapes = sorted((o for o in objs if not ("plugin" in o or "symbol" in o)), key=lambda o: len(o.get("pts", [])))
    lo, hi = 0, len(shapes)
    best = None
    while lo <= hi:  # the most shapes that still fit
        mid = (lo + hi) // 2
        trial = dict(readout, objects=keep + shapes[:mid], trimmed=len(shapes) - mid)
        b = dump(trial)
        if len(b) <= limit:
            best, lo = (b, len(shapes) - mid), mid + 1
        else:
            hi = mid - 1
    if best is None:
        raise ValueError("even the plug-in objects alone are over %d bytes" % limit)
    return best


MESH_PART = ".rigmesh%d.json"


def mesh_part_name(readout_path: Path, n: int) -> Path:
    """<drawing>.rigmesh<n>.json beside <drawing>.rigread.json."""
    return readout_path.with_name(readout_path.name[: -len(SUFFIX)] + MESH_PART % n)


def split(readout: dict, stem: str, limit: int = LIMIT) -> tuple[bytes, list[bytes], int]:
    """The read-out as files Dropbox can hand Rig Studio (each under `limit`). When the whole thing is
    too big, the 3D faces move into "<stem>.rigmesh<n>.json" parts ({"rigmesh": 1, "meshes":
    {"<mid>": mesh}}, each object keeps "mid"), and if the rest is still too big, the plainest shapes
    move into parts too ({"rigmesh": 1, "objects": [...]}) instead of being left out (CFF-26 lost
    2,908 lines that way). The main file lists every part in "mesh_parts". Returns (main, parts,
    shapes left out), and nothing is left out unless even the symbols and plug-ins don't fit."""
    def dump(r):
        return json.dumps(r, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    whole = dump(readout)
    if len(whole) <= limit:
        return whole, [], 0
    objs, meshes = [], []
    for i, o in enumerate(readout["objects"]):
        o = dict(o, k=i)  # its place in the drawing's order: the files below don't keep it
        if "mesh" in o:
            meshes.append((len(meshes), o.pop("mesh")))
            o["mid"] = meshes[-1][0]
        objs.append(o)
    # Faces shared by every copy of a symbol part go into the parts once, as "s<id>"; each object
    # names them in "mid" and keeps its own matrix ("mx").
    for sid, m in (readout.get("shared") or {}).items():
        meshes.append(("s%s" % sid, m))
    for o in objs:
        if "sm" in o:
            o["mid"] = "s%s" % o.pop("sm")
    readout = {kk: v for kk, v in readout.items() if kk != "shared"}

    # What stays in the main file: plug-ins and symbols always, then the plainest shapes that fit
    # (the same order `fit` keeps them in); the rest spills into parts.
    room = limit - 4096  # the part names go in later
    keep = [o for o in objs if "plugin" in o or "symbol" in o]
    shapes = sorted((o for o in objs if not ("plugin" in o or "symbol" in o)), key=lambda o: len(o.get("pts", [])))
    n = len(shapes)
    if len(dump(dict(readout, objects=keep + shapes))) > room:
        lo, hi, n = 0, len(shapes), -1
        while lo <= hi:
            mid = (lo + hi) // 2
            if len(dump(dict(readout, objects=keep + shapes[:mid]))) <= room:
                n, lo = mid, mid + 1
            else:
                hi = mid - 1
        if n < 0:  # not even the symbols and plug-ins: the old trimming, which says what it left out
            main, trimmed = fit(dict(readout, objects=objs), limit)
            return main, [], trimmed
    spill = shapes[n:]

    parts, cur, size = [], {}, 0

    def close():
        nonlocal cur, size
        if cur:
            parts.append(cur)
        cur, size = {}, 0

    for mid, m in meshes:
        b = len(dump(m)) + 12
        if cur and size + b > limit - 64:
            close()
        cur.setdefault("meshes", {})[str(mid)] = m
        size += b
    for o in spill:
        b = len(dump(o)) + 2
        if cur and size + b > limit - 64:
            close()
        cur.setdefault("objects", []).append(o)
        size += b
    close()
    names = [stem + MESH_PART % (i + 1) for i in range(len(parts))]
    main = dump(dict(readout, objects=keep + shapes[:n], mesh_parts=names))
    return main, [dump(dict(rigmesh=1, **p)) for p in parts], 0


def summary(readout: dict) -> dict:
    """Counts a person can read: plug-in types, lighting devices, symbols, shapes, layers."""
    plugins: dict[str, int] = {}
    symbols = shapes = 0
    for o in readout.get("objects", []):
        if "plugin" in o:
            plugins[o["plugin"] or "(unnamed)"] = plugins.get(o["plugin"] or "(unnamed)", 0) + 1
        elif "symbol" in o:
            symbols += 1
        else:
            shapes += 1
    return {
        "document": readout.get("document"),
        "objects": len(readout.get("objects", [])),
        "plugins": dict(sorted(plugins.items(), key=lambda kv: -kv[1])),
        "lighting_devices": plugins.get("Lighting Device", 0),
        "symbols": symbols,
        "shapes": shapes,
        "layers": len(readout.get("layers", [])),
        "truncated": bool(readout.get("truncated")),
    }


def same_document(open_name: str, path: Path) -> bool:
    """Whether the document open in Vectorworks is this file, by name. Converting an older file
    renames the open copy: 'x_v2025.vwx' opens as 'x_v2025_v2026.vwx' (seen on Vectorworks 2026),
    other versions add ' v2026'."""
    a = re.sub(r"\.vwx$", "", open_name, flags=re.I).strip().lower()
    b = path.stem.strip().lower()
    return a == b or bool(re.fullmatch(re.escape(b) + r"[ _]v20\d\d", a)) or (bool(a) and b.startswith(a))


def is_converted_copy(open_name: str, path: Path) -> bool:
    """The open document is the renamed copy Vectorworks made converting this older file (not the
    file itself, and not some other drawing)."""
    a = re.sub(r"\.vwx$", "", open_name or "", flags=re.I).strip().lower()
    b = path.stem.strip().lower()
    return bool(re.fullmatch(re.escape(b) + r"[ _]v20\d\d", a))


def open_in_vectorworks(path: Path, exe: str | None = None) -> None:
    """Open the file in Vectorworks (the running copy's program when known; it opens it in a new
    window), never in whatever app Windows has .vwx set to."""
    from .trigger import open_with

    open_with(path, exe)


def needs_read(vwx: Path) -> bool:
    t = target_for(vwx)
    return not t.exists() or t.stat().st_mtime < vwx.stat().st_mtime


def vwx_files(folder: Path) -> list[Path]:
    """The .vwx files in a folder and below, leaving out Vectorworks' backup folders."""
    return sorted(p for p in folder.rglob("*.vwx") if not any(part.lower() in ("vw backup", "backup") for part in p.parts) and "-backup-" not in p.name.lower())


# ---- watching folders -------------------------------------------------------------------------
# With VWMCP_WATCH set (folders separated by ";"), the connector reads out any .vwx there that is
# new or changed, by itself, but only while nobody is using the PC and Claude hasn't asked
# Vectorworks for anything lately, so it never opens a file under someone's hands.

WATCH_EVERY = 300.0  # seconds between looks
QUIET_FOR = 600.0  # seconds without keyboard/mouse and without Claude before it may open files


def watch_folders(raw: str | None = None) -> list[Path]:
    raw = os.environ.get("VWMCP_WATCH", "") if raw is None else raw
    out = []
    for part in raw.split(";"):
        p = Path(part.strip().strip('"')).expanduser()
        if part.strip() and p.is_dir():
            out.append(p)
    return out


def pending(folders: list[Path]) -> list[Path]:
    """Every watched .vwx whose read-out is missing or older than the file, oldest change first."""
    todo = [p for f in folders for p in vwx_files(f) if needs_read(p)]
    return sorted(todo, key=lambda p: p.stat().st_mtime)


def idle_seconds() -> float | None:
    """Seconds since the last keyboard or mouse input on this PC, or None off Windows."""
    try:
        import ctypes
        from ctypes import wintypes

        class LASTINPUTINFO(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]

        info = LASTINPUTINFO(ctypes.sizeof(LASTINPUTINFO), 0)
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):  # type: ignore[attr-defined]
            return None
        return (ctypes.windll.kernel32.GetTickCount() - info.dwTime) / 1000.0  # type: ignore[attr-defined]
    except Exception:
        return None


def quiet(idle: float | None, since_claude: float, quiet_for: float = QUIET_FOR) -> bool:
    """May the watcher open files now? Unknown idleness counts as busy."""
    return idle is not None and idle >= quiet_for and since_claude >= quiet_for


# ---- read-out requests ------------------------------------------------------------------------
# Rig Studio on the phone asks for a read-out by dropping "<drawing>.<job>.rigrequest.json" beside
# the drawing in Dropbox. Dropbox syncs it to the PC, the connector sees it within seconds (no
# scheduled task, no link to the PC needed), reads the drawing out, and writes
# "<drawing>.rigstatus.json" beside it so the page can say how it went. Requests are explicit, so
# they don't wait for the PC to be quiet.

REQUEST_SUFFIX = ".rigrequest.json"
STATUS_SUFFIX = ".rigstatus.json"
REQUEST_EVERY = 5.0  # seconds between looks for requests
ANSWER_SUFFIX = ".riganswer.json"  # Rig Studio's answer to a box Vectorworks is waiting on
PROMPT_EVERY = 3.0  # seconds between looks for a box while a read-out runs


def dropbox_roots() -> list[Path]:
    """Where Dropbox keeps its folders on this PC, from Dropbox's own info.json."""
    out = []
    for base in (os.environ.get("LOCALAPPDATA"), os.environ.get("APPDATA")):
        if not base:
            continue
        info = Path(base) / "Dropbox" / "info.json"
        try:
            data = json.loads(info.read_text(encoding="utf-8"))
        except Exception:
            continue
        for acct in data.values():
            if isinstance(acct, dict) and acct.get("path"):
                p = Path(acct["path"])
                if p.is_dir() and p not in out:
                    out.append(p)
    return out


def request_folders() -> list[Path]:
    """Folders to look in for requests: VWMCP_REQUESTS if set, else the watched folders plus Dropbox's
    "Rig Studio" folder."""
    raw = os.environ.get("VWMCP_REQUESTS")
    if raw is not None:
        return watch_folders(raw)
    out = list(watch_folders())
    for root in dropbox_roots():
        rs = root / "Rig Studio"
        if rs.is_dir() and rs not in out:
            out.append(rs)
    return out


def requests(folders: list[Path]) -> list[tuple[Path, Path | None, str]]:
    """Every request as (request file, the drawing it names or None, job id), oldest first."""
    found = []
    for f in folders:
        try:
            reqs = list(f.rglob("*" + REQUEST_SUFFIX))
        except OSError:
            continue
        for r in reqs:
            base = r.name[: -len(REQUEST_SUFFIX)]
            best = None
            for v in sorted(r.parent.glob("*.vwx")):
                if base.lower().startswith(v.stem.lower() + ".") and (best is None or len(v.stem) > len(best.stem)):
                    best = v
            job = base[len(best.stem) + 1 :] if best else ""
            try:
                found.append((r.stat().st_mtime, r, best, job))
            except OSError:
                continue
    return [(r, v, j) for _, r, v, j in sorted(found, key=lambda t: t[0])]


def status_path(vwx: Path) -> Path:
    return vwx.with_name(vwx.stem + STATUS_SUFFIX)


def write_status(vwx: Path, **fields) -> Path:
    """Write <drawing>.rigstatus.json beside the drawing (whole file at once, so Dropbox never syncs
    half of it)."""
    import datetime as _dt

    fields["at"] = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    dest = status_path(vwx)
    tmp = dest.with_name(dest.name + ".tmp")
    tmp.write_text(json.dumps(fields, indent=1), encoding="utf-8")
    tmp.replace(dest)
    return dest


def take_answer(vwx: Path, job: str) -> dict | None:
    """Rig Studio's answer to a box (<drawing>.<job>.riganswer.json beside it: {"button", "remember"}),
    removed once read; None if there's none yet."""
    f = vwx.with_name("%s.%s%s" % (vwx.stem, job, ANSWER_SUFFIX))
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    try:
        f.unlink()
    except OSError:
        pass
    return data if isinstance(data, dict) and data.get("button") else None
