"""vwmcp: an MCP bridge between Claude and Vectorworks."""

<<<<<<< HEAD
__version__ = "0.9.13"
=======
__version__ = "0.9.12"
>>>>>>> origin/main
