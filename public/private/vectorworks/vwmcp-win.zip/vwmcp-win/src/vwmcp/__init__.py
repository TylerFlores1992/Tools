"""vwmcp: an MCP bridge between Claude and Vectorworks."""

__version__ = "0.8.0"
