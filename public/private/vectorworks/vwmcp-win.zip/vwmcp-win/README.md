# Vectorworks connector (vwmcp)

Lets Claude draw in, measure and edit the drawing open in Vectorworks on Windows, Spotlight
included; works a show the way a head rigger does (datum, departments, venue limits, every
point's load, bridles, mark-out, revisions); and powers the live panel at
**tylerflores.dev/private/vectorworks**.

```
Claude ──MCP──▶ vwmcp ─┐                      ┌─▶ %USERPROFILE%\.vwmcp\jobs\<id>.json
                       ├─ the same job queue ─┤
Panel page ──HTTP──▶ vwmcp-panel ─┘           └─ presses Ctrl+Shift+Alt+M in Vectorworks
                                                        │
Vectorworks: "MCP Run Job" ▶ vwmcp_bridge.run_pending() ▶ runs each job with `vs`
                                                        ▶ results\<id>.json ▶ back to the caller
```

## Status

| Piece | State |
|---|---|
| MCP server, 61 tools (63 with the optional ones), job queue (retry, timeout, stale-job drop) | Tested over real MCP stdio |
| 3D placement + `build_rig` | Math unit-tested; end to end against the fake. **Not yet run in real Vectorworks** (see "Build a rig from the phone") |
| Bridge inside Vectorworks | Every `vs` call checked against the official signatures; tested against a strict fake of Vectorworks. **Not yet run in a real copy of Vectorworks.** |
| Windows hotkey trigger | Logic tested with Windows faked out; **not yet run on Windows** |
| Panel API (`vwmcp-panel`) + the page on tylerflores.dev | Tested end to end in a real browser against the fake |

## Set up (Windows, Vectorworks 2026 with Spotlight)

1. **Install** (Python 3.11 or newer, from this folder):
   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -e ".[windows]"
   vwmcp-install-plugin
   ```
   This copies the bridge to `%USERPROFILE%\.vwmcp\plugin` and prints two short scripts.

2. **Create two menu commands.** Tools ▸ Plug-ins ▸ Plug-in Manager ▸ Custom Plug-ins ▸ New ▸
   **Command**. Name it `MCP Run Job`, then Edit Script, set the language to **Python**, and paste
   the first script. Do the same for `MCP Session` with the second script.

3. **Add them to your workspace.** Tools ▸ Workspaces ▸ Edit Current Workspace ▸ Menus. Drag
   both into any menu, then give `MCP Run Job` the shortcut **Ctrl+Shift+Alt+M**. If you pick
   another key, set `VWMCP_HOTKEY` to match, in
   [pywinauto syntax](https://pywinauto.readthedocs.io/en/latest/code/pywinauto.keyboard.html):
   `^` Ctrl, `+` Shift, `%` Alt.

4. **Connect Claude.**
   - Claude Code: `claude mcp add vectorworks -- C:\path\to\this\folder\.venv\Scripts\vwmcp.exe`
   - Claude Desktop (`claude_desktop_config.json`):
     ```json
     { "mcpServers": { "vectorworks": { "command": "C:\\path\\to\\this\\folder\\.venv\\Scripts\\vwmcp.exe" } } }
     ```
   Open a drawing and ask Claude to "ping Vectorworks".

5. **The panel (optional).** Run `vwmcp-panel` and open the link it prints. The page pairs with
   this computer and keeps the token in that browser only. The drawing goes straight from your
   computer to the page, never through the website.

**Session mode, if the shortcut misbehaves:** set `VWMCP_TRIGGER=session` and run
**MCP Session**. A small "Claude is connected" window handles requests every quarter second
until you press Stop. It uses Vectorworks' dialog timer, the only timer a script gets.

## First run on real Vectorworks

Do these once, in order, and note anything odd.

1. `ping`: expect `2026 (31.x.x, build …)`, `Windows`, and your units.
2. `vs_lookup query=HMove`: confirms the live API answers, with its signatures.
3. Draw a line and a rectangle, `get_selection` on them, then `undo_last` twice.
4. `get_lighting_devices` on a real plot: check the field names match the table below. If
   Spotlight names a field differently, the panel's fixture fields are in `FIXTURE_FIELDS`
   (`src/tools/vectorworks/ui/Inspector.tsx`).
5. `screenshot`: needs Pillow, which the `[windows]` extra installs.
6. On a real rigging file, `survey_drawing`, then `get_rigging include_fixtures=false`. Check:
   - **Plug-in names.** Each hoist, house point, bridle, truss and load should come back with
     the kind you expect. If one reads as `other`, add its plug-in name to `RIGGING_KINDS` in
     `vw_plugin/vwmcp_bridge.py` (the survey's "Plug-in objects found" lists the exact names).
   - **Heights.** Compare a hoist's `z` with its Object Info height. If they differ by the layer
     elevation, `z` is relative to the layer and the bridge needs `GetLayerElevationN` added.
   - **Viewports.** Objects inside a design layer viewport should say `source: viewport` (or
     `referenced`), never `native`. If one says `native`, `GetParent` doesn't reach viewports
     and `_note_native` is the only thing classifying them.
   - **Braceworks.** If Braceworks has calculated, `load_source` should say `Braceworks`. If it
     says `statics` or `estimate` on a calculated file, the field names differ: read one hoist
     with `get_object include_records=true` and fix the names in `_describe`.
7. `import_dwg` with a venue DWG into a new layer, then `check_scale`. Note what
   `ImportDXFDWGFile` returned on success and on a bad path; the bridge treats 0 as success.

The same list is what the panel's Rigging tab shows, so a wrong kind or height shows there too.

If a **Script Errors** dialog ever appears, a `vs` call disagreed with Vectorworks. Click OK,
copy what it says, and fix that call in `vw_plugin/vwmcp_bridge.py`. The menu command reloads
the bridge on every run, so there's no need to restart Vectorworks.

## Working a show (how a head rigger does it)

Files arrive two ways: **one file** with everyone's work on layers and classes, or **separate
files** (venue, lighting, audio, video, scenic) referenced in as design layer viewports or
imported. Either way the steps are the same, and Claude follows them (they're in the server's
instructions):

1. **See what arrived.** `survey_drawing` names every layer and class, each viewport and the
   file behind it, which plug-in types are present and how each will be read, and anything
   referenced (read-only here: change it in its own file). `check_scale` catches a venue DWG
   that came in at the wrong scale (inches vs millimeters, feet vs inches); `scale_objects`
   fixes it.
2. **Set the datum.** `find_reference_lines` suggests the centerline and plaster line (or DSE);
   `set_datum` stores where they cross and which way upstage is. Every position is then given
   the way it's called out on the floor: `12'-0" SL of CL, 30'-0" US of PL`.
3. **Departments.** Guessed from layer and class names (venue, rigging, lighting, audio, video,
   scenic, staging); `set_departments` fixes any guess, remembered per file.
   `show_departments` turns them on, gray or off, in Vectorworks and in the panel alike.
4. **Venue limits**, from the venue's rigging packet: per point, per beam, roof total, high
   steel, max bridle angle (120° default), weights of truss, cable and chain per foot
   (`set_limits`, in lb or kg).
5. **Work out the rigging.** `rigging_report` gives every point's load and where it came from
   (Braceworks when calculated; otherwise statics for two picks, a continuous-beam estimate for
   three or more, or a load object), the point load with hoist and chain, the dynamic factor,
   use of the hoist's rating, the steel above (dead hang, or a bridle between beams on opposite
   sides with leg lengths and angle), checks worst first, beam and roof totals, and the
   mark-out order. `save_csv` writes the point list beside the drawing.
6. **Revisions.** `save_rigging_revision` keeps the point list; later reports say what was
   added, removed, moved or changed load since.

Tools for the math on its own: `design_bridle` (apex and hook height to legs and tensions),
`bridle_from_legs` (fixed legs to where the apex lands), `truss_loads` (reactions on each pick).
Show settings live in `%USERPROFILE%\.vwmcp\shows\`, one file per drawing.

**Estimates are estimates.** Three or more picks on one truss depend on how level the hoists
are; the report says so on every such point. Check with Braceworks, load cells or an engineer
before anything flies.

## Build a rig from the phone

Design and approve a rig at **tylerflores.dev/private/rig**, then have Claude build it here in
one call. The format both sides share is `docs/RIG.md` (build list v1).

1. **Give the connector the site's token.** Set `VWMCP_RIG_TOKEN` in your Windows user
   environment (the connector reads it from there each time, no restart needed), or add it to the MCP config, e.g. for
   Claude Desktop: `"env": { "VWMCP_RIG_TOKEN": "…" }` next to `"command"`; for Claude Code,
   `claude mcp add vectorworks -e VWMCP_RIG_TOKEN=… -- …\vwmcp.exe`. Restart Claude.
2. **It keeps itself up to date (0.5.4 and later).** Each time the Claude app starts it, the
   connector checks tylerflores.dev with the same key; a newer build is downloaded, its SHA-256
   checked, unpacked over this folder (`pip install -e` installs only), dependencies refreshed if
   they changed, and the new bridge copied to `%USERPROFILE%\.vwmcp\plugin`; then the new code
   starts on the same connection. The symbol names it builds with (`src/vwmcp/symbols.json`) are
   fetched the same way, hourly, so a new truss size or symbol is an edit there plus
   `make_zip.py` and a deploy, with no update at all. `update_connector` checks on demand; `ping`
   shows the connector version, the bridge version and the symbol map in use.
   `VWMCP_AUTO_UPDATE=0` turns this off (then run `vwmcp-install-plugin` after each manual update:
   an old bridge answers "Unknown op …").
3. In Vectorworks, open the file that has the truss, pipe and clamp symbols, and say
   **"build design &lt;id&gt;"**. Claude calls `build_rig(design_id=…)`: everything goes on a
   layer named `Rig` (it refuses a layer that already has objects unless told `replace=true`),
   and the design is marked built on the site. `undo_last` removes the whole build.

The answer lists every part, what it **substituted** (nearest pipe length, nearest clamp angle),
what it **skipped** (base plates for now, sloped truss, kinds it doesn't know yet) and any
**missing symbols** to import first (then nothing is placed). Library names it uses:
`Truss Box 12in x 12in x 10ft/8ft/6ft`, `Pipe 1.5in-<n>ft Length`, and
`Aluminium Scaffold Clamp-<angle> Deg` (0–90°). Only the 12" box series is mapped so far.

Single parts: `place_truss` (centerline start → end, level or plumb), `place_symbol_3d` (a 3D
symbol from two axis vectors, mirrored when the frame is left-handed) and `set_z`. 3D tools take
inches, Z up.

**First real run, check:** a plumb leg lands on its corner block (the half-width Hanging Angle
pivot is corrected); `LineLength` really changes the truss length; the clamps' jaws sit on the
pipe and chord (each part's `readback` is Vectorworks' own `Get3DOrientation`). If the clamps
come out turned the wrong way, `Set3DRot`'s sign or axes differ from the right-hand rule the
bridge assumes (`_place_symbol_3d` in `vw_plugin/vwmcp_bridge.py`).

## Why it's built this way

These come from the official reference (github.com/Vectorworks/developer-scripting, which
developer.vectorworks.net now redirects to) and from a macOS project tested on VW 2026 U3
(giorgiomoroder/vectorworks-mcp).

- **Vectorworks 2026 runs Python 3.9.2.** `tests/test_bridge_static.py` parses the bridge as 3.9.
- **A wrong `vs` call doesn't raise.** It queues a modal Script Errors dialog that blocks the
  app. So `vw_plugin/vs_signatures.json` records the official parameter list of every function
  the bridge calls, and a test fails if any call's argument count or point-tuple form disagrees.
  The fake Vectorworks enforces the same table at run time. Where the reference contradicted
  itself (`Rect` is documented as four numbers but bound as two points), the Python binding wins.
- **Nothing can host a server inside Vectorworks**, and there is no outside API for a running
  copy. So the work goes through a menu command, woken by a shortcut.
- **The trigger is polite.** If you're working in Vectorworks, it waits until your mouse buttons
  are up and you've paused (`VWMCP_IDLE_MS`, default 600), so it never lands mid-drag. From
  another app it fires at once and hands focus back. It refuses while a Vectorworks dialog is
  open, and in the first 30 seconds after launch, because scripting a just-started Vectorworks
  can crash it.
- **Drawings open in Vectorworks itself**, by the running copy's program (else the newest under
  Program Files), never through Windows' ".vwx opens with" setting: on 2026-11-11 that handed the
  blank drawing to a Chromium window and the read-out waited for nothing. With several Vectorworks
  windows, the one with a drawing in its title is used.
- **Boxes get answered, not waited on.** Known boxes (Font Mapping, missing textures or plug-ins,
  "locate", read-only) get the answer that changes nothing; answers you chose are kept in
  `~/.vwmcp/prompts.json`. An unknown box is reported with its words and buttons (`answer_prompt`),
  and a phone read-out passes it to Rig Studio to tap.
- **Objects are addressed by UUID** (`GetObjectUuid`), because handles only live for one run.
  `GetName` says `"none"` for unnamed objects; the bridge reports `""`.
- **Ctrl+Z merges consecutive scripted runs**, so the bridge keeps its own journal and
  `undo_last` reverses Claude's changes one at a time. A batch counts as one change. Deletes,
  color changes and new layers say they need Ctrl+Z.
- **ResetObject applies at the end of a run.** So moves report the exact new geometry by
  translating what was read, rather than re-reading stale plug-in objects.
- **Lighting Device Universe and DMX Address** are written together as `UniverseAddress`
  (`2/101`). Spotlight overwrites either one written alone.
- **Fixtures are only placed with symbols already in the file** (`list_symbols`). A lighting
  device pointing at a missing symbol can damage a .vwx.
- **Referenced files have no script API.** Objects from a referenced viewport are found by
  searching with and without `NOTINREFDLVP`/`NOTINDLVP`, labeled by source, and refused for
  edits, so nothing tries to change a file that isn't open.
- **No script can export the view**, so `screenshot` captures the Vectorworks window itself.
  `snapshot` draws an SVG from geometry and works everywhere.

## Tools

| Group | Tools |
|---|---|
| Document | `ping`, `get_document_info`, `create_layer`, `create_class` |
| Draw | `draw_line`, `draw_rectangle`, `draw_circle`, `draw_arc`, `draw_polygon`, `add_text`, `add_dimension`, `draw_wall`, `place_symbol`, `list_symbols` |
| Read & measure | `list_objects`, `get_selection`, `get_object`, `measure_distance` |
| Edit | `move_objects`, `rotate_object`, `duplicate_objects`, `set_object_properties`, `set_attributes`, `group_objects`, `delete_objects`, `select_objects`, `zoom_to` |
| Spotlight | `get_lighting_devices`, `set_record_fields`, `place_lighting_device` |
| Show setup | `survey_drawing`, `get_show_setup`, `find_reference_lines`, `set_datum`, `set_departments`, `set_limits`, `show_departments`, `where_is` |
| Rigging | `get_rigging`, `rigging_report`, `save_rigging_revision`, `design_bridle`, `bridle_from_legs`, `truss_loads` |
| Venue files | `import_dwg`, `check_scale`, `scale_objects` |
| 3D & rigs | `build_rig`, `place_truss`, `place_symbol_3d`, `set_z` |
| Workflow | `batch` (many steps, one round trip, one undo), `undo_last`, `vs_lookup` |
| Look | `screenshot` (Windows), `snapshot` (SVG) |
| Optional | `run_python` (needs `VWMCP_ALLOW_EXEC=1` and a file named `allow_exec` in `%USERPROFILE%\.vwmcp`); `end_session` (session mode) |

Lengths may be numbers (drawing units) or strings with units: `12'-6"`, `6 1/2"`, `20 ft`,
`450mm`, `1.2 m`. The panel reads them with the same rules, tested against the same cases
(`src/tools/vectorworks/length-cases.json`).

Lighting Device fields seen in Spotlight 2026: Inst Type, Channel, Unit Number, Position,
Purpose, Color, Wattage, Dimmer, Universe, DMX Address, UniverseAddress, Absolute Address,
Circuit Number, Circuit Name, Template, Template2, Focus, Mark, Symbol Name, Device Type,
User Field 1–6. `get_lighting_devices` lists whatever your version actually has.

## Settings

| Variable | Default | Meaning |
|---|---|---|
| `VWMCP_TRIGGER` | `menu` | `menu` presses Tools > MCP Run Job through Windows' accessibility interface (no keys, works while Windows is locked; measured on the owner's PC 2026-11-10), falling back to the shortcut when unlocked. `hotkey`, `session`, `none` as before |
| `VWMCP_MENU` / `VWMCP_MENU_ITEM` | `Tools` / `MCP Run Job` | Where the menu trigger finds the command |
| `VWMCP_HOTKEY` | `^+%m` | Shortcut bound to MCP Run Job |
| `VWMCP_IDLE_MS` | `600` | How long you must pause in Vectorworks before a request runs |
| `VWMCP_BLANK` | `Claude connector.vwx` on the Desktop (or in Documents) | A blank drawing opened by itself when Vectorworks is running with no drawing (its menu commands are off until one is open). The shortcut also refuses, with a plain reason, while Windows is on the lock screen |
| `VWMCP_WINDOW_RE` | `.*Vectorworks.*` | Window title to find |
| `VWMCP_PROCESS_RE` | `(?i)^vectorworks[^\\/]*\.exe$` | The window's program must match too, so a browser tab titled "Vectorworks" (the panel page) is never pressed. If "No Vectorworks window found" names Vectorworks' own program, set this to match it |
| `VWMCP_RESTORE_FOCUS` | `1` | Hand focus back to where you were |
| `VWMCP_TIMEOUT` | `30` | Seconds to wait for Vectorworks |
| `VWMCP_REFIRE_AFTER` | `3` | Press again if a job sits unclaimed this long |
| `VWMCP_ALLOW_EXEC` | `0` | Offer `run_python` |
| `VWMCP_PANEL_PORT` | `7377` | Panel API port (always 127.0.0.1) |
| `VWMCP_PANEL_ORIGINS` | tylerflores.dev, localhost:3000 | Pages allowed to use the panel API |
| `VWMCP_HOME` | `%USERPROFILE%\.vwmcp` | Queue, journal, token, installed bridge |
| `VWMCP_RIG_TOKEN` | (none) | Bearer token for fetching Rig Planner designs (`build_rig design_id=…`) |
| `VWMCP_RIG_URL` | `https://tylerflores.dev` | Where designs are fetched from |
| `VWMCP_RIG_TIMEOUT` | `180` | Seconds a whole `build_rig` may take inside Vectorworks |
| `VWMCP_AUTO_UPDATE` | `1` | Update the connector and its symbol map from the site at start |

## Panel API safety

`vwmcp-panel` binds 127.0.0.1 only. Every call except `/api/health` needs the pairing token
(`%USERPROFILE%\.vwmcp\panel_token`). Browsers may only call it from `VWMCP_PANEL_ORIGINS`.
The Host header must be localhost, which blocks DNS rebinding. Only an allow-list of operations
runs; `run_python` never does. Each of these has a test that fails if the guard is removed.

## Develop without Vectorworks

```powershell
pip install -e ".[dev]"
pytest                                    # against a strict fake Vectorworks
python dev\fake_vectorworks.py --demo     # a plot with a deck, a truss and 4 fixtures
python dev\fake_vectorworks.py --show     # a rigging file: steel, 2 trusses on 5 hoists,
                                          # 12 fixtures, scenery, a referenced audio file
```

With the fake running, `VWMCP_TRIGGER=none vwmcp-panel` and the MCP server both work end to
end, on any OS.

## Layout

```
src/vwmcp/     server.py (MCP tools) · panel.py (local HTTP API) · jobs.py (queue) ·
               trigger.py (hotkey, idle wait, guards, capture) · svg.py · install.py · config.py
               update.py (self-update) · symbols.py + symbols.json (symbol names as data)
               readout.py (read_out: the drawing as <name>.rigread.json beside the .vwx;
               VWMCP_WATCH folders are read out by themselves when the PC is quiet)
               service.py (show workflow) · show.py (datum, departments, limits, per file) ·
               rigging.py (bridles, truss reactions, units) · report.py (point list, checks) ·
               rig.py (Rig Planner build lists: frames, clamps, truss insertion; no vs)
vw_plugin/     vwmcp_bridge.py (runs in Vectorworks) · menu_run_job.py · menu_session.py ·
               vs_signatures.json (official parameter lists for every vs call used)
dev/           fake_vs.py (strict in-memory Vectorworks) · fake_vectorworks.py (queue watcher)
tests/         bridge static checks, round trips, units, trigger, panel API, rigging math,
               show setup, the head-rigger workflow end to end
make_zip.py    builds the download behind /private/vectorworks, its update manifest and symbols.json
```

## Importing symbols by itself (0.5.0)

`build_rig` imports any truss, pipe, clamp, deck or leg symbol the file is missing from
Vectorworks' own library files before it builds (`auto_import=false` to only list them), and
`import_symbols` does the same for any names. It reads the files under the application's
`Libraries` folder and `%APPDATA%\Nemetschek\Vectorworks\<year>\Libraries` (downloaded
content), likeliest first, and keeps what each file holds in `~/.vwmcp/library_index.json`, so
only the first search is slow. `VWMCP_LIBRARY_ROOTS` (folders separated by `;`) replaces those
folders, e.g. to add a workgroup library. Content still in the cloud (red in the Resource
Manager) isn't on disk, so it can't be found until it's downloaded once.
